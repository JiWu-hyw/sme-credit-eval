/**
 * 静态 SPA 托管（生产同构）
 *
 * 只做一件事，但这件事出过线上事故，所以单独成文：
 *
 *   **`/api/*` 绝不回落 index.html。**
 *
 * 事故经过（2026-10-22）：托管的 history fallback 对所有 GET 都返回 200 + index.html，
 * 于是 `GET /api/data/pipeline` 也拿到一坨 HTML。axios 认为请求成功，
 * 前端拿到 `res.data` 是一段字符串而不是 `{ code, message, data }` 信封，
 * 页面读 `pipeline.nodes` 得到 undefined → 整页被错误态替换，表现为白屏。
 *
 * 现在两条防线：
 *   ① 服务端（本文件）：`/api/*` 未配置代理时一律 404 + JSON，**不回落**；
 *   ② 前端（src/api/index.ts 的 isEnvelope）：形状不对就在 auto 模式下降级 mock。
 * 只靠任何一条都不够 —— 前端防线会让故障静默变成"用了假数据"，
 * 后端防线会让本地开发没有 mock 就无法工作，所以两条都留、各司其职。
 *
 * 另外：静态资源找不到就真 404，不要拿 index.html 顶替 .js/.css，
 * 否则浏览器会以 "Unexpected token '<'" 的诡异形式报错，排查方向全错。
 *
 * 用法：PORT=8080 node serve/server.mjs
 * 环境变量：
 *   PORT       监听端口（默认 8080）
 *   DIST_DIR   产物目录（默认 <repo>/frontend/dist）
 *   API_PROXY  可选，后端地址如 http://127.0.0.1:8000（配了就把 /api/* 反代过去）
 */
import { createReadStream, existsSync, statSync } from 'node:fs'
import { createServer } from 'node:http'
import { extname, join, normalize, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const here = fileURLToPath(new URL('.', import.meta.url))
/**
 * 产物目录按「存在的那个」解析，不写死相对层数。
 * 踩坑（FE-14 交付包）：仓库里本文件在 serve/，`../frontend/dist` 正好；
 * 但交付包把 serve/ 压平到根目录，同一条路径就指到包外面去了 ——
 * 表现为服务起得来、首页 500、test:dist 报"静态服务没起来"，
 * 排查方向全错（人以为端口或权限问题）。
 */
const DIST_CANDIDATES = [join(here, 'frontend/dist'), join(here, '../frontend/dist'), join(here, 'dist')]
const DIST = resolve(
  process.env.DIST_DIR || DIST_CANDIDATES.find((p) => existsSync(p)) || DIST_CANDIDATES[1],
)
const PORT = Number(process.env.PORT || 8080)
const API_PROXY = process.env.API_PROXY || ''

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.map': 'application/json; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
}

/** 带缓存头地发一个文件；返回 false 表示文件不存在 */
const sendFile = (req, res, filePath) => {
  if (!existsSync(filePath) || !statSync(filePath).isFile()) return false
  const ext = extname(filePath).toLowerCase()
  // 带 hash 的产物可以长缓存，index.html 必须每次回源 —— 否则发版后用户拿到旧壳
  const immutable = /\.[0-9a-zA-Z_-]{8,}\.(js|css|woff2?)$/.test(filePath)
  res.writeHead(200, {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Cache-Control': immutable ? 'public, max-age=31536000, immutable' : 'no-cache',
  })
  createReadStream(filePath).pipe(res)
  return true
}

const sendJson = (res, status, body) => {
  const text = JSON.stringify(body)
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' })
  res.end(text)
}

/** 极简反代：只为本地联调，够用即可（不处理 chunked 之外的协议细节） */
const proxy = async (req, res) => {
  const target = new URL(req.url, API_PROXY)
  try {
    const upstream = await fetch(target, {
      method: req.method,
      headers: { ...req.headers, host: target.host },
      body: ['GET', 'HEAD'].includes(req.method) ? undefined : req,
      duplex: 'half',
    })
    const buf = Buffer.from(await upstream.arrayBuffer())
    res.writeHead(upstream.status, {
      'Content-Type': upstream.headers.get('content-type') || 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
    })
    res.end(buf)
  } catch (err) {
    sendJson(res, 502, { code: 502, message: `后端不可达：${String(err.message || err)}`, data: null })
  }
}

const server = createServer(async (req, res) => {
  const rawPath = decodeURIComponent(new URL(req.url, 'http://x').pathname)

  /* ---------- ① /api/*：要么反代，要么 404 + JSON，绝不回落 HTML ---------- */
  if (rawPath === '/api' || rawPath.startsWith('/api/')) {
    if (API_PROXY) return proxy(req, res)
    return sendJson(res, 404, {
      code: 404,
      message:
        '本服务只托管前端静态产物，未配置后端。前端在 auto 模式下会降级到本地契约 mock；' +
        '如需真数据，请用 API_PROXY=http://127.0.0.1:8000 启动。',
      data: null,
    })
  }

  if (req.method !== 'GET' && req.method !== 'HEAD') {
    return sendJson(res, 405, { code: 405, message: 'Method Not Allowed', data: null })
  }

  /* ---------- ② 静态文件：先精确命中，命中不了再走 SPA 回落 ---------- */
  // normalize + 前缀校验，挡住 `../` 穿越到 dist 之外
  const safe = normalize(rawPath).replace(/^(\.\.[/\\])+/, '')
  const filePath = join(DIST, safe)
  if (!filePath.startsWith(DIST)) return sendJson(res, 403, { code: 403, message: 'Forbidden', data: null })

  if (rawPath !== '/' && sendFile(req, res, filePath)) return

  // 目录或根路径 → index.html
  if (rawPath === '/' || rawPath.endsWith('/')) {
    if (sendFile(req, res, join(DIST, 'index.html'))) return
    return sendJson(res, 500, { code: 500, message: `产物目录没有 index.html：${DIST}`, data: null })
  }

  /* ---------- ③ 带扩展名的路径：真 404 ----------
   * `/assets/foo.js` 不存在时回 index.html，浏览器会报
   * "Unexpected token '<'" 而不是 404，排查方向会被带偏。 */
  if (extname(rawPath)) {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' })
    return res.end(`Not Found: ${rawPath}`)
  }

  /* ---------- ④ 无扩展名的前端路由：回 index.html（history fallback） ---------- */
  if (sendFile(req, res, join(DIST, 'index.html'))) return
  sendJson(res, 500, { code: 500, message: `产物目录没有 index.html：${DIST}`, data: null })
})

server.listen(PORT, '0.0.0.0', () => {
  console.log(`静态服务已启动 http://127.0.0.1:${PORT}  (dist=${DIST})`)
  console.log(API_PROXY ? `/api/* → ${API_PROXY}` : '/api/* → 404 + JSON（不回落 index.html）')
})
