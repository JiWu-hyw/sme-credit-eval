import { chromium } from 'playwright'
import { createServer } from 'vite'
import { fileURLToPath } from 'node:url'
const server = await createServer({
  root: fileURLToPath(new URL('.', import.meta.url)),
  configFile: fileURLToPath(new URL('./vite.config.ts', import.meta.url)),
  mode: 'test',
  define: { 'import.meta.env.VITE_USE_MOCK': JSON.stringify('mock') },
  server: { host: '127.0.0.1', port: 11590, strictPort: true },
  logLevel: 'error',
})
await server.listen()
const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', args: ['--no-sandbox'] })
const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 1.5 })
const page = await ctx.newPage()
await page.goto('http://127.0.0.1:11590/graph', { waitUntil: 'networkidle' })
await page.waitForTimeout(4500)
const shot = async (name, sel) => {
  if (!sel) { await page.screenshot({ path: `/root/work/shots/${name}.png`, fullPage: true }); return }
  const el = await page.$(`#${sel}`)
  const sec = await el.evaluateHandle((h) => h.closest('section'))
  await sec.asElement().screenshot({ path: `/root/work/shots/${name}.png` })
}
await shot('p3-e1', 'e1')
await shot('p3-e2', 'e2')
await shot('p3-e3', 'e3')
await shot('p3-e4', 'e4')
await browser.close(); await server.close()
