import { chromium } from 'playwright'
import { createServer } from 'vite'
import { fileURLToPath } from 'node:url'
const server = await createServer({ root: fileURLToPath(new URL('.', import.meta.url)), configFile: fileURLToPath(new URL('./vite.config.ts', import.meta.url)), mode: 'test', define: { 'import.meta.env.VITE_USE_MOCK': JSON.stringify('mock') }, server: { port: 11593, strictPort: true }, logLevel: 'error' })
await server.listen()
const b = await chromium.launch({ executablePath: '/usr/bin/chromium', args: ['--no-sandbox'] })
const ctx = await b.newContext({ viewport: { width: 1440, height: 960 } })
const p = await ctx.newPage()
await p.goto('http://127.0.0.1:11593/graph', { waitUntil: 'networkidle' })
await p.waitForTimeout(3000)
// 模拟冒烟中的流程：先操作一圈，再点
const canvas = p.locator('[data-testid="chart-panel"] canvas').first()
const box = await canvas.boundingBox()
console.log('box', box)
let found = 0
for (let y = box.y + 20; y < box.y + box.height - 20; y += 16) {
  for (let x = box.x + 20; x < box.x + box.width - 20; x += 16) {
    await p.mouse.click(x, y)
    if (await p.locator('[data-testid="node-drawer"]').count()) { found++; console.log('hit at', x - box.x, y - box.y); break }
  }
  if (found) break
}
console.log('found', found)
// 直接派发 echarts 事件测试 handler 是否在
const ev = await p.evaluate(() => {
  const c = document.querySelector('[data-testid="chart-panel"] canvas')
  return { hasCanvas: !!c, w: c?.width, h: c?.height }
})
console.log(ev)
await b.close(); await server.close()
