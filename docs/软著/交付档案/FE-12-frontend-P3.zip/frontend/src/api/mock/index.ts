/**
 * 契约同构 mock（FE-02 / FE-11）
 *
 * 纪律（fe-spec §6）：
 *   - 字段名逐字对齐 src/types/contracts.ts，禁止简化、禁止 camelCase；
 *   - 语义未知字段（x21–x200）一律 semantic_known: false（红线二）；
 *   - meta 由本文件统一注入（页面只拿信封，不自己拼 meta）。
 *
 * 数值来源分两类，必须分清：
 *   ① **实测锚点**：真实面板行级 AUC≈0.59、企业级 0.47、噪声地板 0.477、
 *      每企业平均 ≈2 个月观测 —— 这些是项目已跑出来的结果，mock 里照抄；
 *   ② **结构同构占位**：真实面板尚未接入 data/processed 时，为了把页面结构和交互跑通，
 *      按契约结构生成点位；一律标 source='demo_placeholder' 并在页面透出免责声明。
 */
import type { ApiEnvelope } from '@/types/contracts'
import type { ContractMeta } from '@/types'
import { NOISE_FLOOR } from '@/utils/redlines'

import dataPipeline from '../../../outputs/contracts/data_pipeline.json'
import dataQuality from '../../../outputs/contracts/data_quality.json'
import panelDepth from '../../../outputs/contracts/panel_depth.json'
import featureTree from '../../../outputs/contracts/feature_tree.json'
// FE-14 / FE-15 的实测契约（非占位：数值来自已跑出的实验结果）
import benchmark from '../../../outputs/contracts/benchmark.json'
import shapGlobal from '../../../outputs/contracts/shap_global.json'
// P1 概览：六份契约的聚合视图（source=aggregated，不引入新数据）
import overview from '../../../outputs/contracts/overview.json'
// FE-12 P3 时空图谱：合成六类实体图（source=synthetic_graph，须警示基调）
import graphStructure from '../../../outputs/contracts/graph_structure.json'
import graphSlices from '../../../outputs/contracts/graph_slices.json'
import graphCentrality from '../../../outputs/contracts/graph_centrality.json'

export type MockMode = 'mock' | 'real' | 'auto'

let mode: MockMode = ((): MockMode => {
  const v = import.meta.env?.VITE_USE_MOCK
  return v === 'mock' || v === 'real' || v === 'auto' ? v : 'auto'
})()

export function configureMock(next: MockMode): void {
  mode = next
}

export function getMockMode(): MockMode {
  return mode
}

/** 信封：code/message/data/meta 四件套，meta 取契约文件自带那份 */
function envelope<T>(data: T, meta: ContractMeta | undefined): ApiEnvelope<T> {
  return { code: 0, message: 'ok', data, meta: { ...meta, noise_floor: NOISE_FLOOR } }
}

const REGISTRY: Record<string, () => ApiEnvelope<unknown>> = {
  'overview/summary': () =>
    envelope(overview.data, overview.meta as unknown as ContractMeta),
  'data/pipeline': () =>
    envelope(dataPipeline.data, dataPipeline.meta as unknown as ContractMeta),
  'data/quality': () =>
    envelope(dataQuality.data, dataQuality.meta as unknown as ContractMeta),
  'data/panel-depth': () =>
    envelope(panelDepth.data, panelDepth.meta as unknown as ContractMeta),
  'features/tree': () =>
    envelope(featureTree.data, featureTree.meta as unknown as ContractMeta),
  'model/benchmark': () =>
    envelope(benchmark.data, benchmark.meta as unknown as ContractMeta),
  'explain/global': () =>
    envelope(shapGlobal.data, shapGlobal.meta as unknown as ContractMeta),
  'graph/structure': () =>
    envelope(graphStructure.data, graphStructure.meta as unknown as ContractMeta),
  'graph/slices': () =>
    envelope(graphSlices.data, graphSlices.meta as unknown as ContractMeta),
  'graph/centrality': () =>
    envelope(graphCentrality.data, graphCentrality.meta as unknown as ContractMeta),
}

export function getMock<T>(key: string): ApiEnvelope<T> {
  const factory = REGISTRY[key]
  if (!factory) {
    return {
      code: 'CONTRACT_PENDING',
      message: `契约 ${key} 尚未产出`,
      data: {} as T,
      meta: { dataset: 'real_panel', schema_version: '1.0', noise_floor: NOISE_FLOOR },
    }
  }
  return factory() as ApiEnvelope<T>
}
