<script setup lang="ts">
/**
 * P5 可解释性（全局 SHAP）
 *
 * 数据来源：GET /api/explain/global（实测契约 outputs/contracts/shap_global.json）
 *   两个模型各给 top-20 的 mean|SHAP|、占比、方向（风险 +1 / 保护 −1）。
 *
 * 这一页要传达的核心事实：模型排出来的重要字段**全部是语义未知的代号**。
 * 所以页面刻意不写"哪些财务指标最重要"这类结论，而是把「解释比例」摆出来：
 * 语义未知字段占了 |SHAP| 的 100%，这不是算法没做好，是字段字典没到。
 */
import { computed, ref } from 'vue'

import ChartPanel from '@/components/ChartPanel.vue'
import PageSkeleton from '@/components/PageSkeleton.vue'
import RedLineBanner from '@/components/RedLineBanner.vue'
import StatePanel from '@/components/StatePanel.vue'
import UnknownFieldTag from '@/components/UnknownFieldTag.vue'
import { fetchShapGlobal } from '@/api'
import { useAsyncSection } from '@/composables/useAsyncSection'
import type { ShapGlobal } from '@/types/contracts'
import type { ContractMeta, DatasetKind } from '@/types'
import { NOISE_FLOOR } from '@/utils/redlines'

const section = useAsyncSection(fetchShapGlobal)

const payload = computed<ShapGlobal | null>(() => {
  const env = section.data.value as { data?: ShapGlobal } | null
  const raw = env?.data
  return raw && Array.isArray(raw.models) ? raw : null
})
const meta = computed<ContractMeta>(() => {
  const env = section.data.value as { meta?: ContractMeta } | null
  return env?.meta ?? {}
})
const dataset = computed<DatasetKind>(() => (meta.value.dataset as DatasetKind) ?? 'real_panel')
const noiseFloor = computed(() => meta.value.noise_floor ?? NOISE_FLOOR)
const status = computed(() => section.status.value)

/** 当前查看的模型，默认 XGBoost（树模型更常用、也更稳） */
const activeId = ref<'xgb' | 'lr'>('xgb')
const active = computed(() => payload.value?.models.find((m) => m.model_id === activeId.value) ?? null)

const modelLabel = (id: string) => payload.value?.models.find((m) => m.model_id === id)?.model_label ?? id

/**
 * 横向条形图：feature（y 轴，代号）× mean|SHAP|（x 轴）。
 * 方向用颜色区分：风险因子（推高违约概率）用红，保护因子用蓝。
 * 语义未知的柱条加斜纹底 —— 颜色之外再给一层编码，截图归档/色弱也能分辨。
 */
const barOption = computed(() => {
  const rows = [...(active.value?.top ?? [])].slice(0, 15).reverse()
  return {
    animation: false,
    grid: { left: 84, right: 72, top: 12, bottom: 28 },
    tooltip: {
      trigger: 'item',
      formatter: (p: { dataIndex: number }) => {
        const r = rows[p.dataIndex]
        return [
          `<b>${r.feature}</b>${r.semantic_known ? '' : '（语义未知）'}`,
          `mean|SHAP| ${r.mean_abs_shap.toFixed(4)}（占全部 ${(r.share * 100).toFixed(2)}%）`,
          r.direction > 0 ? '风险因子：值越大越推高违约概率' : '保护因子：值越大越降低违约概率',
        ].join('<br/>')
      },
    },
    xAxis: {
      type: 'value',
      name: 'mean|SHAP|',
      nameTextStyle: { fontSize: 10, color: '#5b6673' },
      axisLabel: { fontSize: 10, color: '#5b6673' },
      splitLine: { lineStyle: { color: '#eef1f5' } },
    },
    yAxis: {
      type: 'category',
      data: rows.map((r) => r.feature),
      axisLabel: { fontSize: 10, fontFamily: 'monospace', color: '#1f2933' },
      axisTick: { show: false },
    },
    series: [
      {
        type: 'bar',
        barWidth: 12,
        label: {
          show: true,
          position: 'right',
          fontSize: 9,
          color: '#5b6673',
          formatter: (p: { dataIndex: number }) =>
            `${(rows[p.dataIndex].share * 100).toFixed(1)}%`,
        },
        data: rows.map((r) => ({
          value: r.mean_abs_shap,
          itemStyle: {
            color: r.direction > 0 ? '#b3312c' : '#2f5d8a',
            opacity: r.semantic_known ? 0.95 : 0.66,
          },
        })),
      },
    ],
  }
})

/** 两个模型 top-10 的重合度：判断解释是否稳定 */
const overlap = computed(() => {
  const models = payload.value?.models ?? []
  if (models.length < 2) return null
  const a = new Set(models[0].top.slice(0, 10).map((r) => r.feature))
  const b = models[1].top.slice(0, 10).map((r) => r.feature)
  const same = b.filter((f) => a.has(f))
  return { same, n: same.length }
})

const fmtPct = (v: number) => `${(v * 100).toFixed(1)}%`
</script>

<template>
  <div class="page">
    <header class="page__head">
      <div class="page__title-row cluster">
        <h1 class="page__title">P5 可解释性</h1>
        <span class="page__sub">1 个接口 · GET /api/explain/global</span>
        <span class="page__meta">
          数据来源 <code>{{ dataset }}</code>
          <template v-if="meta.n_samples">· 解释集 n={{ meta.n_samples }}</template>
        </span>
      </div>
      <p class="page__lede">
        全局解释回答「模型靠什么做判断」。本页把两个模型的 top-20 贡献摆出来，并顺手标出每根柱子属于风险因子还是保护因子；
        但更重要的是右上角那个数字——语义已知字段的解释占比。它现在是 0。
      </p>
    </header>

    <RedLineBanner scope="P5 可解释性" :count="payload?.n_features_used" />

    <PageSkeleton v-if="status === 'loading'" :kpi-count="3" :charts="[420]" />
    <StatePanel
      v-else-if="status === 'error'"
      variant="error"
      title="全局解释数据未能加载"
      :reason="section.error.value?.reason ?? ''"
      :next-step="section.error.value?.nextStep ?? ''"
      :retry="() => void section.retry()"
    />
    <template v-else-if="payload">
      <!-- 结论 -->
      <section class="page__verdict" aria-labelledby="verdict">
        <h2 id="verdict" class="page__verdict-title">这一页真正想说的一句话</h2>
        <p class="page__verdict-text">{{ payload.conclusion }}</p>
      </section>

      <!-- KPI -->
      <div class="grid-12">
        <div class="col-4 card">
          <span class="card__label">语义未知字段解释占比</span>
          <strong class="card__value card__value--warn">{{ fmtPct(active?.unknown_field_share ?? 0) }}</strong>
          <span class="card__hint">x21–x200 之外一个都没有 —— 不是模型挑不出来，是字段字典没到</span>
        </div>
        <div class="col-4 card">
          <span class="card__label">Top-20 累计解释占比</span>
          <strong class="card__value">{{ fmtPct(active?.top20_share ?? 0) }}</strong>
          <span class="card__hint">{{ active?.n_features }} 个特征里，前 20 个就解释了绝大部分</span>
        </div>
        <div class="col-4 card">
          <span class="card__label">两模型 Top-10 重合</span>
          <strong class="card__value">{{ overlap ? `${overlap.n} / 10` : '—' }}</strong>
          <span class="card__hint">{{ overlap?.same.join('、') || '—' }}</span>
        </div>
      </div>

      <!-- 切换模型 -->
      <div class="page__switch" role="group" aria-label="选择解释的模型">
        <button
          v-for="m in payload.models"
          :key="m.model_id"
          type="button"
          :aria-pressed="activeId === m.model_id"
          :class="{ 'is-active': activeId === m.model_id }"
          @click="activeId = m.model_id as 'xgb' | 'lr'"
        >
          {{ m.model_label }}
        </button>
        <span class="page__switch-hint">解释集：{{ payload.explain_set }}</span>
      </div>

      <!-- 条形图 -->
      <div class="grid-12">
        <div class="col-7">
          <ChartPanel
            :title="`${modelLabel(activeId)} · 全局特征贡献 Top-15（mean|SHAP|）`"
            :dataset="dataset"
            :n-samples="meta.n_samples"
            :noise-floor="noiseFloor"
            :option="barOption"
            :height="420"
          >
            <ul class="legend" aria-label="颜色图例">
              <li><span class="legend__dot legend__dot--risk" />风险因子（值越大越推高违约概率）</li>
              <li><span class="legend__dot legend__dot--protect" />保护因子（值越大越降低违约概率）</li>
              <li><span class="legend__dot legend__dot--faint" />浅色 = 语义未知字段</li>
            </ul>
            <p class="page__note">
              所有柱条都是深浅不一的"未知"：颜色只区分方向，代号本身不含业务含义。
              这就是「模型可解释但业务不可读」的具体样子。
            </p>
          </ChartPanel>
        </div>

        <div class="col-5">
          <section class="page__block" aria-labelledby="toplist">
            <header class="page__block-head">
              <h2 id="toplist" class="page__block-title">Top-20 明细</h2>
            </header>
            <div class="table-scroll table-scroll--tall">
              <table class="tbl">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">字段</th>
                    <th scope="col">mean|SHAP|</th>
                    <th scope="col">占比</th>
                    <th scope="col">方向</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="r in active?.top" :key="r.feature">
                    <td class="mono">{{ r.rank }}</td>
                    <th scope="row"><UnknownFieldTag :field="r.feature" :semantic-known="r.semantic_known" /></th>
                    <td class="mono">{{ r.mean_abs_shap.toFixed(4) }}</td>
                    <td class="mono">{{ (r.share * 100).toFixed(2) }}%</td>
                    <td>
                      <span class="dir" :data-dir="r.direction">
                        {{ r.direction > 0 ? '风险 +' : '保护 −' }}
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>
        </div>
      </div>

      <!-- 为什么是 0 -->
      <section class="page__block" aria-labelledby="why">
        <header class="page__block-head">
          <span class="page__code">Q</span>
          <h2 id="why" class="page__block-title">为什么解释占比是 0，而不是"模型没学到东西"</h2>
        </header>
        <div class="qa">
          <div class="qa__item">
            <p class="qa__q">模型确实学到了东西吗？</p>
            <p class="qa__a">
              学到了，但很弱：留出集 AUC 0.586（LR）/ 0.576（XGB），置换对照地板 0.477。
              比地板高 0.1 左右，说明存在微弱信号，但不足以支撑放贷决策。
            </p>
          </div>
          <div class="qa__item">
            <p class="qa__q">那为什么一个业务字段都排不进前 20？</p>
            <p class="qa__a">
              面板里 x1–x20 这 20 个「语义相对清楚」的字段，在当前特征筛选后贡献接近噪声；
              真正被模型抓住的全在 x21–x200。字段字典补齐前，没人能说出 x125 代表什么。
            </p>
          </div>
          <div class="qa__q-item qa__item">
            <p class="qa__q">下一步做什么？</p>
            <p class="qa__a">
              不是调模型，是补字段字典（P0-2）与技术要素/成长轨迹数据（P0-4、P0-5）。
              数据到位后，本页结构不变，柱条上的代号会变成「发明专利授权率」「下一轮融资额」这类可读名。
            </p>
          </div>
        </div>
      </section>
    </template>

    <footer class="page__foot cluster">
      <span>下一步：</span>
      <RouterLink :to="{ name: 'model' }" class="page__link">P4 模型与对比</RouterLink>
      <span class="page__foot-sep">·</span>
      <RouterLink :to="{ name: 'data' }" class="page__link">P2 数据与特征</RouterLink>
      <span class="page__foot-sep">·</span>
      <span>局部归因（单企业边扰动 / GNNExplainer）与「阶段-因子-权重」决策图谱待 FE-16 落地。</span>
    </footer>
  </div>
</template>

<style scoped>
.page {
  display: flex;
  flex-direction: column;
  gap: var(--space-5);
}

.page__head {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
}

.page__title {
  font-size: 22px;
  font-weight: 700;
}

.page__sub,
.page__meta {
  font-size: 12px;
  color: var(--color-text-muted);
}

.page__meta code {
  font-family: var(--font-mono);
  font-size: 11px;
  padding: 0 4px;
  border-radius: 2px;
  background: var(--color-surface-muted);
}

.page__lede {
  max-width: 960px;
  font-size: 13px;
  line-height: 1.75;
  color: var(--color-text-muted);
}

.page__verdict {
  padding: var(--space-4) var(--space-5);
  border-left: 3px solid var(--risk-high-risk);
  border-radius: var(--radius-md);
  background: var(--risk-high-risk-bg);
}

.page__verdict-title {
  font-size: 13px;
  font-weight: 700;
  color: var(--risk-high-risk);
  margin-bottom: var(--space-1);
}

.page__verdict-text {
  font-size: 13px;
  line-height: 1.85;
  color: var(--color-text);
}

.card {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
  padding: var(--space-4);
  background: var(--color-surface);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
}

.card__label {
  font-size: 12px;
  color: var(--color-text-muted);
}

.card__value {
  font-family: var(--font-mono);
  font-size: 24px;
  font-weight: 700;
}

.card__value--warn {
  color: var(--risk-high-risk);
}

.card__hint {
  font-size: 11px;
  line-height: 1.6;
  color: var(--color-text-subtle);
}

.page__switch {
  display: flex;
  align-items: center;
  gap: var(--space-2);
}

.page__switch button {
  min-height: 32px;
  padding: 0 var(--space-3);
  border: 1px solid var(--color-border-strong);
  border-radius: 16px;
  background: var(--color-surface);
  font-size: 12px;
  color: var(--color-text-muted);
  cursor: pointer;
}

.page__switch button.is-active {
  border-color: var(--color-accent);
  color: var(--color-accent);
  background: var(--color-accent-soft);
}

.page__switch-hint {
  margin-left: auto;
  font-size: 11px;
  color: var(--color-text-subtle);
}

.legend {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-4);
  margin: var(--space-2) 0 0;
  padding: 0;
  list-style: none;
  font-size: 11px;
  color: var(--color-text-muted);
}

.legend__dot {
  display: inline-block;
  width: 9px;
  height: 9px;
  margin-right: 5px;
  border-radius: 2px;
  vertical-align: middle;
}

.legend__dot--risk {
  background: #b3312c;
}

.legend__dot--protect {
  background: #2f5d8a;
}

.legend__dot--faint {
  background: #b9c0c9;
}

.page__block {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  padding: var(--space-5);
  background: var(--color-surface);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
}

.page__block-head {
  display: flex;
  align-items: baseline;
  flex-wrap: wrap;
  gap: var(--space-3);
}

.page__code {
  padding: 0 6px;
  border-radius: var(--radius-sm);
  background: var(--color-accent-soft);
  color: var(--color-accent);
  font-family: var(--font-mono);
  font-size: 11px;
}

.page__block-title {
  font-size: 16px;
  font-weight: 600;
}

.page__note {
  font-size: 12px;
  line-height: 1.8;
  color: var(--color-text-muted);
}

.tbl {
  width: 100%;
  border-collapse: collapse;
  font-size: 12px;
}

.tbl th,
.tbl td {
  padding: 6px 8px;
  border-bottom: 1px solid var(--color-border);
  text-align: right;
  white-space: nowrap;
}

.tbl th[scope='col']:nth-child(2),
.tbl th[scope='row'] {
  text-align: left;
}

.tbl thead th {
  position: sticky;
  top: 0;
  font-weight: 600;
  color: var(--color-text-muted);
  background: var(--color-surface-muted);
}

.table-scroll {
  overflow: auto;
}

.table-scroll--tall {
  /* 实测 20 行 × 33px + 表头 = 692px。Top-20 是本页的核心证据，不该被截成
     「默认只露 18 行、剩下靠滚动」——截图归档时那 2 行会被当成数据缺失。
     所以这里给足高度（700px），横向滚动仍保留。 */
  max-height: 700px;
}

.mono {
  font-family: var(--font-mono);
}

.dir {
  font-size: 11px;
  padding: 0 5px;
  border-radius: 8px;
  border: 1px solid currentColor;
}

.dir[data-dir='1'] {
  color: var(--risk-high-risk);
}

.dir[data-dir='-1'] {
  color: var(--color-accent);
}

.qa {
  display: grid;
  gap: var(--space-3);
}

.qa__q {
  font-size: 13px;
  font-weight: 600;
  color: var(--color-text);
  margin-bottom: 2px;
}

.qa__a {
  font-size: 12.5px;
  line-height: 1.85;
  color: var(--color-text-muted);
}

.page__foot {
  padding: var(--space-3) 0;
  border-top: 1px solid var(--color-border);
  font-size: 12px;
  color: var(--color-text-muted);
}

.page__link {
  color: var(--color-accent);
}

.page__foot-sep {
  color: var(--color-text-subtle);
}
</style>
