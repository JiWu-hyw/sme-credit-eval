<script setup lang="ts">
/**
 * P4 模型与对比
 *
 * 数据来源：GET /api/model/benchmark（实测契约，非占位）
 *   行级 CV / 企业级 CV / 打乱标签置换对照 / holdout 四块。
 *
 * 这页要回答的问题不是"模型有多好"，而是"这点效果有多少是真的"：
 *   - 行级 AUC≈0.59 与噪声地板 0.477 摆在一起看；
 *   - 企业级 AUC 0.47 直接低于抛硬币；
 *   - 图模型对比无图 MLP 只 +0.013。
 * 所以页头先给结论，图表是证据。
 */
import { computed } from 'vue'

import ChartPanel from '@/components/ChartPanel.vue'
import MetricBar from '@/components/MetricBar.vue'
import PageSkeleton from '@/components/PageSkeleton.vue'
import RedLineBanner from '@/components/RedLineBanner.vue'
import StatePanel from '@/components/StatePanel.vue'
import UnknownFieldTag from '@/components/UnknownFieldTag.vue'
import { fetchBenchmark } from '@/api'
import { useAsyncSection } from '@/composables/useAsyncSection'
import type { Benchmark } from '@/types/contracts'
import type { ContractMeta, DatasetKind } from '@/types'
import { NOISE_FLOOR } from '@/utils/redlines'

const section = useAsyncSection(fetchBenchmark)

const payload = computed<Benchmark | null>(() => {
  const env = section.data.value as { data?: Benchmark } | null
  const raw = env?.data
  return raw && Array.isArray(raw.levels) ? raw : null
})
const meta = computed<ContractMeta>(() => {
  const env = section.data.value as { meta?: ContractMeta } | null
  return env?.meta ?? {}
})
const dataset = computed<DatasetKind>(() => (meta.value.dataset as DatasetKind) ?? 'real_panel')
const noiseFloor = computed(() => meta.value.noise_floor ?? NOISE_FLOOR)
const isMeasured = computed(() => meta.value.source === 'measured')

const status = computed(() => section.status.value)

const HOLDOUT_ORDER = ['lr', 'xgb', 'gat', 'mlp_nograph']

const holdoutModels = computed(() => {
  const list = payload.value?.holdout.models ?? []
  return [...list].sort(
    (a, b) => HOLDOUT_ORDER.indexOf(a.model_id) - HOLDOUT_ORDER.indexOf(b.model_id),
  )
})

const gat = computed(() => holdoutModels.value.find((m) => m.model_id === 'gat'))
const mlp = computed(() => holdoutModels.value.find((m) => m.model_id === 'mlp_nograph'))

/** 图增益：图模型 − 无图对照（同为 holdout，同特征） */
const graphGain = computed(() => {
  if (!gat.value || !mlp.value) return null
  return gat.value.metrics.auc - mlp.value.metrics.auc
})

/** 行级 vs 企业级：同一批特征，聚合方式不同 */
const rowLevel = computed(() => payload.value?.levels.find((l) => !l.is_permutation_control && l.level_id === 'row'))
const companyLevel = computed(() => payload.value?.levels.find((l) => l.level_id === 'company'))

const REFS = computed(() => [
  { value: 0.5, label: '抛硬币 0.5', tone: 'neutral' as const },
  { value: payload.value?.noise_floor.value ?? NOISE_FLOOR, label: '噪声地板', tone: 'danger' as const },
])

/** 四条 holdout AUC —— 同屏只放真实面板数据（红线一） */
const aucOption = computed(() => {
  const rows = holdoutModels.value
  return {
    animation: false,
    grid: { left: 132, right: 56, top: 16, bottom: 32 },
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      formatter: (ps: Array<{ name: string; value: number }>) =>
        ps.map((p) => `${p.name}：AUC ${Number(p.value).toFixed(4)}`).join('<br/>'),
    },
    xAxis: {
      type: 'value',
      min: 0.4,
      max: 0.7,
      axisLabel: { fontSize: 11, color: '#5b6673' },
      splitLine: { lineStyle: { color: '#eef1f5' } },
    },
    yAxis: {
      type: 'category',
      data: rows.map((m) => m.model_label),
      axisLabel: { fontSize: 11, color: '#1f2933' },
      axisTick: { show: false },
    },
    series: [
      {
        type: 'bar',
        barWidth: 16,
        data: rows.map((m) => ({
          value: m.metrics.auc,
          itemStyle: { color: m.model_id === 'gat' ? '#2f5d8a' : m.model_id === 'mlp_nograph' ? '#8a939e' : '#b9c0c9' },
        })),
        markLine: {
          silent: true,
          symbol: 'none',
          lineStyle: { color: '#b3312c', type: 'dashed', width: 1 },
          label: { formatter: `噪声地板 ${payload.value?.noise_floor.value ?? NOISE_FLOOR}`, fontSize: 10, color: '#b3312c' },
          data: [{ xAxis: payload.value?.noise_floor.value ?? NOISE_FLOOR }],
        },
      },
    ],
  }
})

/** 行级 vs 企业级：两组 × 两模型 */
const levelOption = computed(() => {
  const levels = [rowLevel.value, companyLevel.value].filter(Boolean)
  return {
    animation: false,
    grid: { left: 48, right: 24, top: 32, bottom: 28 },
    tooltip: { trigger: 'axis' },
    legend: {
      top: 0,
      textStyle: { fontSize: 11, color: '#5b6673' },
      data: ['Logistic 回归', 'XGBoost'],
    },
    xAxis: {
      type: 'category',
      data: levels.map((l) => `${l!.level_label}`),
      axisLabel: { fontSize: 10, color: '#5b6673', interval: 0, width: 120, overflow: 'break' },
      axisTick: { show: false },
    },
    yAxis: {
      type: 'value',
      min: 0.4,
      max: 0.7,
      axisLabel: { fontSize: 11, color: '#5b6673' },
      splitLine: { lineStyle: { color: '#eef1f5' } },
    },
    series: [
      {
        name: 'Logistic 回归',
        type: 'bar',
        barWidth: 18,
        data: levels.map((l) => l!.models.find((m) => m.model_id === 'lr')?.metrics_mean.auc ?? 0),
        itemStyle: { color: '#b9c0c9' },
      },
      {
        name: 'XGBoost',
        type: 'bar',
        barWidth: 18,
        data: levels.map((l) => l!.models.find((m) => m.model_id === 'xgb')?.metrics_mean.auc ?? 0),
        itemStyle: { color: '#2f5d8a' },
      },
    ],
  }
})

const fmt = (v: number | undefined, d = 3) => (typeof v === 'number' ? v.toFixed(d) : '—')
</script>

<template>
  <div class="page">
    <header class="page__head">
      <div class="page__title-row cluster">
        <h1 class="page__title">P4 模型与对比</h1>
        <span class="page__sub">1 个接口 · GET /api/model/benchmark</span>
        <span class="page__meta">
          数据来源 <code>{{ dataset }}</code>
          <template v-if="meta.n_samples">· n={{ meta.n_samples }}</template>
          <span class="page__badge" :data-measured="isMeasured">
            {{ isMeasured ? '实测结果' : '占位数据' }}
          </span>
        </span>
      </div>
      <p class="page__lede">
        这一页回答的不是「模型多好」，而是「这点效果有多少是真的」。四个模型放在同一张留出集（698 条 / 75 正例）上，
        旁边摆着置换对照的噪声地板；行级与企业级分开呈现，因为把同一企业的多个月观测聚成一条之后，信号会消失。
      </p>
    </header>

    <RedLineBanner scope="P4 模型与对比" />

    <PageSkeleton v-if="status === 'loading'" :kpi-count="4" :charts="[320, 320]" />
    <StatePanel
      v-else-if="status === 'error'"
      variant="error"
      title="模型对比数据未能加载"
      :reason="section.error.value?.reason ?? ''"
      :next-step="section.error.value?.nextStep ?? ''"
      :retry="() => void section.retry()"
    />
    <template v-else-if="payload">
      <!-- 结论先行 -->
      <section class="page__verdict" aria-labelledby="verdict">
        <h2 id="verdict" class="page__verdict-title">结论先行</h2>
        <ul class="page__verdict-list">
          <li v-for="n in payload.notes" :key="n">{{ n }}</li>
        </ul>
      </section>

      <!-- KPI -->
      <div class="grid-12">
        <div class="col-3 card">
          <span class="card__label">行级 AUC（LR）</span>
          <strong class="card__value">{{ fmt(rowLevel?.models.find((m) => m.model_id === 'lr')?.metrics_mean.auc) }}</strong>
          <span class="card__hint">噪声地板 {{ fmt(payload.noise_floor.value) }}，差 {{ fmt((rowLevel?.models.find((m) => m.model_id === 'lr')?.metrics_mean.auc ?? 0) - payload.noise_floor.value) }}</span>
        </div>
        <div class="col-3 card">
          <span class="card__label">企业级 AUC（XGB）</span>
          <strong class="card__value card__value--warn">{{ fmt(companyLevel?.models.find((m) => m.model_id === 'xgb')?.metrics_mean.auc) }}</strong>
          <span class="card__hint">低于 0.5：聚合后信号消失</span>
        </div>
        <div class="col-3 card">
          <span class="card__label">图模型增益（GAT − 无图 MLP）</span>
          <strong class="card__value">{{ graphGain === null ? '—' : (graphGain >= 0 ? '+' : '') + fmt(graphGain) }}</strong>
          <span class="card__hint">同特征、同划分，只差图结构</span>
        </div>
        <div class="col-3 card">
          <span class="card__label">留出集</span>
          <strong class="card__value">{{ payload.holdout.n_test }}</strong>
          <span class="card__hint">正例 {{ payload.holdout.n_pos }} · 训练 {{ payload.holdout.n_train }}（按 userid 分组）</span>
        </div>
      </div>

      <!-- 四条模型 AUC -->
      <div class="grid-12">
        <div class="col-7">
          <ChartPanel
            title="留出集 AUC：基线 / 图模型 / 无图对照"
            :dataset="dataset"
            :n-samples="payload.holdout.n_test"
            :noise-floor="noiseFloor"
            :option="aucOption"
            :height="320"
          >
            <p class="page__note">
              四条柱子都挤在 0.55–0.58 之间，彼此差不到 0.02；离红色虚线（噪声地板）只有 0.08–0.10。
              这不是「模型选型问题」，是数据里能用的信息本来就少。
            </p>
          </ChartPanel>
        </div>
        <div class="col-5">
          <ChartPanel
            title="行级 vs 企业级（同特征，不同聚合）"
            :dataset="dataset"
            :n-samples="rowLevel?.n_samples"
            :noise-floor="noiseFloor"
            :option="levelOption"
            :height="320"
          >
        <p class="page__note">
          行级 3,465 条 → 企业级 1,714 条：把同一企业的多个月观测合成一条后，AUC 从 0.596 掉到 0.479，
          已经跌破 0.5 的抛硬币线。这不是模型退化，是「聚合把信号平均掉了」。
        </p>
          </ChartPanel>
        </div>
      </div>

      <!-- 指标明细 -->
      <section class="page__block" aria-labelledby="holdout-table">
        <header class="page__block-head">
          <span class="page__code">T1</span>
          <h2 id="holdout-table" class="page__block-title">留出集指标明细</h2>
          <p class="page__block-desc">阈值 0.5 下的指标；阈值不在这里调，避免在测试集上调参</p>
        </header>
        <div class="table-scroll">
          <table class="tbl">
            <thead>
              <tr>
                <th scope="col">模型</th>
                <th scope="col">AUC</th>
                <th scope="col">KS</th>
                <th scope="col">准确率</th>
                <th scope="col">精确率</th>
                <th scope="col">召回率</th>
                <th scope="col">F1</th>
                <th scope="col">最佳 F1（阈值）</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="m in holdoutModels" :key="m.model_id" :data-emph="m.model_id === 'gat'">
                <th scope="row">{{ m.model_label }}</th>
                <td class="mono">{{ fmt(m.metrics.auc) }}</td>
                <td class="mono">{{ fmt(m.metrics.ks) }}</td>
                <td class="mono">{{ fmt(m.metrics.accuracy) }}</td>
                <td class="mono">{{ fmt(m.metrics.precision) }}</td>
                <td class="mono">{{ fmt(m.metrics.recall) }}</td>
                <td class="mono">{{ fmt(m.metrics.f1) }}</td>
                <td class="mono">{{ fmt(m.best_f1) }}（{{ m.best_f1_threshold }}）</td>
              </tr>
            </tbody>
          </table>
        </div>
        <p class="page__note">
          召回率 0.6–0.72 看着不低，是靠把阈值压到 0.5、正例权重放大到负例的 9.56 倍换来的；
          同时精确率只有 0.13——「抓到的多是误报」。指标要成对读，不能只挑好看的那个。
        </p>
      </section>

      <!-- 交叉验证与置换对照 -->
      <section class="page__block" aria-labelledby="cv">
        <header class="page__block-head">
          <span class="page__code">T2</span>
          <h2 id="cv" class="page__block-title">5 折交叉验证与置换对照</h2>
          <p class="page__block-desc">均值 ± 标准差；打乱标签那一组就是噪声地板本身</p>
        </header>
        <div class="cv-grid">
          <div v-for="lv in payload.levels" :key="lv.level_id" class="cv-card" :data-control="lv.is_permutation_control">
            <h3 class="cv-card__title">
              {{ lv.level_label }}
              <span v-if="lv.is_permutation_control" class="cv-card__tag">对照</span>
            </h3>
            <p class="cv-card__meta">
              n={{ lv.n_samples }} · 组 {{ lv.n_groups }} · {{ lv.n_splits }} 折 · top-{{ lv.k_features }} 特征
            </p>
            <MetricBar
              v-for="m in lv.models"
              :key="m.model_id"
              :label="m.model_label"
              :value="m.metrics_mean.auc"
              :std="m.metrics_std.auc"
              :refs="lv.is_permutation_control ? [] : REFS"
              :emphasize="lv.is_permutation_control"
            />
          </div>
        </div>
        <p class="page__note">
          误差带是 5 折标准差。行级 AUC 0.596 ± 0.040 与打乱标签 0.492 ± 0.056 的区间有明显重叠——
          这也是为什么本项目把「能否超过噪声地板」当成判断信号真伪的第一道闸，而不是只看 AUC 绝对值。
        </p>
      </section>

      <!-- 特征口径 -->
      <section class="page__block" aria-labelledby="feat">
        <header class="page__block-head">
          <span class="page__code">T3</span>
          <h2 id="feat" class="page__block-title">进入模型的 top-{{ payload.holdout.selected_features.length }} 特征</h2>
          <p class="page__block-desc">按 |点二列相关| 在折内训练集上筛选，无跨折泄漏</p>
        </header>
        <ul class="feat-list">
          <li v-for="f in payload.holdout.selected_features" :key="f">
            <UnknownFieldTag :field="f" :semantic-known="false" />
          </li>
        </ul>
        <p class="page__note">
          全部是 x21–x200 的语义未知字段：字段字典未补齐前，模型层能证明「有信号」，但无法说明「信号是什么」。
        </p>
      </section>
    </template>

    <footer class="page__foot cluster">
      <span>下一步：</span>
      <RouterLink :to="{ name: 'explain' }" class="page__link">P5 可解释性</RouterLink>
      <span class="page__foot-sep">·</span>
      <span>红线：真实面板结果与合成图结果不得同图比较（合成图那一组只在 P3 出现，不进本页任何坐标轴）。</span>
    </footer>
  </div>
</template>

<style scoped>
.page {
  display: flex;
  flex-direction: column;
  gap: var(--space-5);
}

.page__head {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
}

.page__title {
  font-size: 22px;
  font-weight: 700;
}

.page__sub,
.page__meta {
  font-size: 12px;
  color: var(--color-text-muted);
}

.page__meta code {
  font-family: var(--font-mono);
  font-size: 11px;
  padding: 0 4px;
  border-radius: 2px;
  background: var(--color-surface-muted);
}

.page__badge {
  margin-left: var(--space-2);
  padding: 0 6px;
  border-radius: 10px;
  font-size: 11px;
  border: 1px solid var(--color-border-strong);
  color: var(--color-text-muted);
}

.page__badge[data-measured='true'] {
  border-color: var(--color-accent);
  color: var(--color-accent);
  background: var(--color-accent-soft);
}

.page__lede {
  max-width: 960px;
  font-size: 13px;
  line-height: 1.75;
  color: var(--color-text-muted);
}

.page__verdict {
  padding: var(--space-4) var(--space-5);
  border-left: 3px solid var(--risk-high-risk);
  border-radius: var(--radius-md);
  background: var(--risk-high-risk-bg);
}

.page__verdict-title {
  font-size: 13px;
  font-weight: 700;
  color: var(--risk-high-risk);
  margin-bottom: var(--space-2);
}

.page__verdict-list {
  margin: 0;
  padding-left: 1.1em;
  font-size: 12.5px;
  line-height: 1.9;
  color: var(--color-text);
}

.card {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
  padding: var(--space-4);
  background: var(--color-surface);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
}

.card__label {
  font-size: 12px;
  color: var(--color-text-muted);
}

.card__value {
  font-family: var(--font-mono);
  font-size: 24px;
  font-weight: 700;
}

.card__value--warn {
  color: var(--risk-high-risk);
}

.card__hint {
  font-size: 11px;
  color: var(--color-text-subtle);
}

.page__block {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  padding: var(--space-5);
  background: var(--color-surface);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
}

.page__block-head {
  display: flex;
  align-items: baseline;
  flex-wrap: wrap;
  gap: var(--space-3);
}

.page__code {
  padding: 0 6px;
  border-radius: var(--radius-sm);
  background: var(--color-accent-soft);
  color: var(--color-accent);
  font-family: var(--font-mono);
  font-size: 11px;
}

.page__block-title {
  font-size: 16px;
  font-weight: 600;
}

.page__block-desc {
  font-size: 12px;
  color: var(--color-text-muted);
}

.page__note {
  font-size: 12px;
  line-height: 1.8;
  color: var(--color-text-muted);
}

.tbl {
  width: 100%;
  border-collapse: collapse;
  font-size: 12.5px;
}

.tbl th,
.tbl td {
  padding: 8px 10px;
  border-bottom: 1px solid var(--color-border);
  text-align: right;
  white-space: nowrap;
}

.tbl th[scope='col']:first-child,
.tbl th[scope='row'] {
  text-align: left;
}

.tbl thead th {
  font-weight: 600;
  color: var(--color-text-muted);
  background: var(--color-surface-muted);
}

.tbl tr[data-emph='true'] {
  background: var(--color-accent-soft);
}

.mono {
  font-family: var(--font-mono);
}

.cv-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: var(--space-4);
}

@media (max-width: 1180px) {
  .cv-grid {
    grid-template-columns: 1fr;
  }
}

.cv-card {
  padding: var(--space-4);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
}

.cv-card[data-control='true'] {
  border-color: var(--risk-high-risk);
  background: var(--risk-high-risk-bg);
}

.cv-card__title {
  font-size: 13px;
  font-weight: 600;
}

.cv-card__tag {
  margin-left: var(--space-2);
  padding: 0 6px;
  font-size: 10px;
  border-radius: 8px;
  color: var(--risk-high-risk);
  border: 1px solid var(--risk-high-risk);
}

.cv-card__meta {
  margin: var(--space-1) 0 var(--space-3);
  font-size: 11px;
  color: var(--color-text-subtle);
}

.feat-list {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-2);
  margin: 0;
  padding: 0;
  list-style: none;
}

.page__foot {
  padding: var(--space-3) 0;
  border-top: 1px solid var(--color-border);
  font-size: 12px;
  color: var(--color-text-muted);
}

.page__link {
  color: var(--color-accent);
}

.page__foot-sep {
  color: var(--color-text-subtle);
}
</style>
