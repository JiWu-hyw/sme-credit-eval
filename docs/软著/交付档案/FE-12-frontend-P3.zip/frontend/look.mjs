import { chromium } from 'playwright'
import { createServer } from 'vite'
import { fileURLToPath } from 'node:url'
const server = await createServer({
  root: fileURLToPath(new URL('.', import.meta.url)),
  configFile: fileURLToPath(new URL('./vite.config.ts', import.meta.url)),
  mode: 'test',
  define: { 'import.meta.env.VITE_USE_MOCK': JSON.stringify('mock') },
  server: { host: '127.0.0.1', port: 11590, strictPort: true },
  logLevel: 'error',
})
await server.listen()
const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', args: ['--no-sandbox'] })
const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 2 })
const page = await ctx.newPage()
const errs = []
page.on('pageerror', e => errs.push(e.message))
page.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text().slice(0, 300)) })
await page.goto('http://127.0.0.1:11590/graph', { waitUntil: 'networkidle', timeout: 60000 })
await page.waitForTimeout(4000)
await page.screenshot({ path: '/root/work/shots/p3-full.png', fullPage: true })
console.log('ERR', errs.slice(0, 5))
console.log('BODY', (await page.innerText('body')).slice(0, 1500))
await browser.close()
await server.close()
