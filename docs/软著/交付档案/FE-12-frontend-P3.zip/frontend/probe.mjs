import { chromium } from 'playwright'
import { createServer } from 'vite'
import { fileURLToPath } from 'node:url'
const server = await createServer({ root: fileURLToPath(new URL('.', import.meta.url)), configFile: fileURLToPath(new URL('./vite.config.ts', import.meta.url)), mode: 'test', define: { 'import.meta.env.VITE_USE_MOCK': JSON.stringify('mock') }, server: { port: 11591, strictPort: true }, logLevel: 'error' })
await server.listen()
const b = await chromium.launch({ executablePath: '/usr/bin/chromium', args: ['--no-sandbox'] })
const p = await (await b.newContext({ viewport: { width: 1440, height: 1000 } })).newPage()
const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => m.type()==='error' && errs.push(m.text().slice(0,200)))
await p.goto('http://127.0.0.1:11591/graph', { waitUntil: 'networkidle' })
await p.waitForTimeout(4000)
// 切到介数中心性，看是否重排
const before = await p.$$eval('.cent__pair figure:first-child tbody, .cent__pair', els => els.length)
const canvases = await p.$$eval('.cent__pair canvas', els => els.map(c => [c.width, c.height, c.parentElement.clientHeight]))
console.log('canvases', canvases)
console.log('errs', errs)
await b.close(); await server.close()
