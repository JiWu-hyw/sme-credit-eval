import { chromium } from 'playwright'
import { createServer } from 'vite'
import { fileURLToPath } from 'node:url'
const server = await createServer({ root: fileURLToPath(new URL('.', import.meta.url)), configFile: fileURLToPath(new URL('./vite.config.ts', import.meta.url)), mode: 'test', define: { 'import.meta.env.VITE_USE_MOCK': JSON.stringify('mock') }, server: { port: 11592, strictPort: true }, logLevel: 'error' })
await server.listen()
const b = await chromium.launch({ executablePath: '/usr/bin/chromium', args: ['--no-sandbox'] })
const p = await (await b.newContext({ viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 1.5 })).newPage()
const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => m.type()==='error' && errs.push(m.text().slice(0,200)))
await p.goto('http://127.0.0.1:11592/graph', { waitUntil: 'networkidle' })
await p.waitForTimeout(4000)

// 点击画布中央附近，尝试命中节点
const canvas = (await p.$('[data-testid="chart-panel"] canvas'))
const box = await canvas.boundingBox()
let hit = false
for (let dx = -200; dx <= 200 && !hit; dx += 20) {
  for (let dy = -150; dy <= 150 && !hit; dy += 20) {
    await p.mouse.click(box.x + box.width/2 + dx, box.y + box.height/2 + dy)
    hit = !!(await p.$('[data-testid="node-drawer"]'))
  }
}
console.log('drawer opened:', hit)
if (hit) {
  await p.waitForTimeout(600)
  await p.screenshot({ path: '/root/work/shots/p3-e4-drawer.png', fullPage: false })
  console.log('title', await p.innerText('[data-testid="node-drawer-title"]'))
  console.log('degree', await p.innerText('[data-testid="node-drawer-degree"]'))
  await p.keyboard.press('Escape')
  await p.waitForTimeout(300)
  console.log('closed by Esc:', !(await p.$('[data-testid="node-drawer"]')))
}
console.log('errs', errs)
await b.close(); await server.close()
