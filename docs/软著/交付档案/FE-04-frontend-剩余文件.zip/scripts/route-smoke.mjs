/**
 * 路由冒烟测试（FE-00 验收项：七路由占位页可跳转）
 *
 * 用 Vite 的 SSR 通道真实编译并渲染 App + 七个页面组件，
 * 断言每个路由都能渲染出对应页面骨架，且过程中无 Vue 运行时告警。
 * 每次渲染都新建 app 实例 —— 复用实例会触发 v-scx 重复注入的假告警。
 *
 * 用法：node scripts/route-smoke.mjs
 */
import { createPinia } from 'pinia'
import { createServer } from 'vite'
import { createSSRApp } from 'vue'
import { renderToString } from 'vue/server-renderer'
import { createMemoryHistory, createRouter } from 'vue-router'

/** 路径严格对齐《前端页面与交互原型说明》v1.0 §三 的路由表 */
const CASES = [
  ['/', 'P1', '概览'],
  ['/data', 'P2', '数据与特征'],
  ['/graph', 'P3', '时空图谱'],
  ['/model', 'P4', '模型与对比'],
  ['/explain', 'P5', '可解释性'],
  ['/forecast', 'P6', '前瞻预测'],
  ['/enterprise/u0001', 'P7', '单企业深度诊断'],
]

const vite = await createServer({
  server: { middlewareMode: true },
  appType: 'custom',
  logLevel: 'error',
})

let failed = 0

const report = (ok, label, extra = '') => {
  if (!ok) failed += 1
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${label}${extra}`)
}

try {
  const { default: App } = await vite.ssrLoadModule('/src/App.vue')
  const { ROUTES, NAV_ROUTES } = await vite.ssrLoadModule('/src/router/routes.ts')

  /** 新建一套 router + app，渲染指定路径，返回 html 与 Vue 告警列表 */
  async function render(path) {
    const warnings = []
    const router = createRouter({ history: createMemoryHistory(), routes: ROUTES })
    const app = createSSRApp(App)

    app.use(createPinia())
    app.use(router)
    app.config.warnHandler = (msg) => warnings.push(msg)

    await router.push(path)
    await router.isReady()

    return { router, html: await renderToString(app), warnings }
  }

  for (const [path, code, title] of CASES) {
    const { html, warnings } = await render(path)
    const checks = [
      ['页面编号', html.includes(code)],
      ['页面标题', html.includes(title)],
      ['占位面板', html.includes('占位页')],
      ['导航项', (html.match(/data-testid="nav-item"/g) ?? []).length >= 7],
    ]
    const bad = checks.filter(([, ok]) => !ok).map(([name]) => name)

    report(
      bad.length === 0 && warnings.length === 0,
      `${path.padEnd(20)} ${code} ${title}`,
      (bad.length ? `  ← 未通过：${bad.join('、')}` : '') +
        (warnings.length ? `  ← 告警：${warnings.join(' | ')}` : ''),
    )
  }

  const notFound = await render('/not-a-page')
  report(notFound.html.includes('404'), '/not-a-page 兜底 404')

  // P7 的 userid 是可选的：无参时也应落到 P7（供导航占位使用）
  const noParam = await render('/enterprise')
  report(
    noParam.html.includes('P7') && noParam.html.includes('未提供'),
    '/enterprise（无 userid）落到 P7 占位态',
  )

  const navCount = ROUTES.filter((r) => r.meta?.nav !== false).length
  report(navCount === 7, `导航项数量 = ${navCount}（期望 7）`)

  // 导航一律用 name 解析：P7 必须解析为 /enterprise，而不是带占位符的模板串
  const probe = createRouter({ history: createMemoryHistory(), routes: ROUTES })
  for (const item of NAV_ROUTES) {
    const resolved = probe.resolve({ name: item.name })
    const ok =
      resolved.name === item.name && typeof resolved.path === 'string' && !resolved.path.includes(':')
    report(ok, `导航 ${item.meta.code} ${item.name} → ${resolved.path}`)
  }

  // `/overview` 不是契约路由，必须落到兜底而不是静默重定向
  const stray = probe.resolve('/overview')
  report(stray.name === 'not-found', `/overview 未定义 → 落到 ${String(stray.name)}`)
} finally {
  await vite.close()
}

console.log(failed === 0 ? '\n路由冒烟测试全部通过' : `\n存在 ${failed} 项失败`)
process.exit(failed === 0 ? 0 : 1)
