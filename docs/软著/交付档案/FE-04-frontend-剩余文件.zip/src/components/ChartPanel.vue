<script setup lang="ts">
import { computed } from 'vue'

import DatasetBadge from './DatasetBadge.vue'
import EChartBase from '../charts/EChartBase.vue'
import NoiseFloorNote from './NoiseFloorNote.vue'

import { CHART_HEIGHT } from '../charts/sizes'
import type { DatasetKind } from '../types'
import type { EChartsOption } from '../charts/echarts'

/**
 * 图表容器（红线一 / 红线三的强制落点，FE-03）。
 *
 * 为什么要有它：红线要求「任一图表容器缺角标即不合格」。把 EChartBase 包在
 * ChartPanel 里并让 `dataset` 成为**必填 prop**，业务代码想要画图就必须提供
 * 数据来源——TypeScript 层直接把「缺角标」变成编译错误，比约定和 review 可靠。
 *
 * - 角标内嵌渲染、不可关闭（DatasetBadge 本身无关闭状态）；
 * - `dataset === 'real_panel'` 且传入 `noiseFloor` 时自动同屏渲染噪声地板注记
 *   （红线三：真实面板性能图必须带地板，当前 0.477）；
 * - 同图混排的运行期守卫见 `utils/redlines.ts › assertSingleDataset`，
 *   由各页面在组装 series 前调用。
 */
const props = withDefaults(
  defineProps<{
    /** 图表标题（可追溯要求：每图有出处） */
    title: string
    /** 数据来源（meta.dataset），必填 → 缺角标即编译不过 */
    dataset: DatasetKind
    /** meta.n_samples，随角标展示 */
    nSamples?: number
    /** meta.noise_floor；real_panel 性能图必须传（红线三） */
    noiseFloor?: number | null
    option: EChartsOption
    /**
     * 高度：数字按 px。默认取 `charts/sizes.ts › CHART_HEIGHT.line`（320）。
     * 力导向图请显式传 `CHART_HEIGHT.force`（640）；热力图传 `'auto'` 由容器决定。
     */
    height?: number | string
    loading?: boolean
  }>(),
  { height: CHART_HEIGHT.line, loading: false, nSamples: undefined, noiseFloor: undefined },
)

const showNoiseFloor = computed(
  () => props.dataset === 'real_panel' && props.noiseFloor !== undefined,
)

/**
 * 高度归一：`'auto'` 交给父容器（热力图自适应），其余原样下发。
 * 不在这里做 `number → 'xxxpx'` 的转换——EChartBase 可能依赖数字做尺寸计算，
 * 少一次类型漂移就少一个「图表高度突然变成 0」的排查。
 */
const chartHeight = computed(() => (props.height === 'auto' ? '100%' : props.height))
</script>

<template>
  <figure class="chart-panel" data-testid="chart-panel">
    <figcaption class="chart-panel__head">
      <span class="chart-panel__title">{{ title }}</span>
      <!-- 角标：不可关闭、不可省略（红线一） -->
      <DatasetBadge :dataset="dataset" :n-samples="nSamples" />
    </figcaption>
    <EChartBase :option="option" :height="chartHeight" :loading="loading" />
    <!-- 噪声地板：真实面板性能图同屏（红线三） -->
    <NoiseFloorNote v-if="showNoiseFloor" :floor="noiseFloor" />
    <slot />
  </figure>
</template>

<style scoped>
.chart-panel {
  margin: 0;
  padding: var(--space-4);
  background: var(--color-surface);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
}

.chart-panel__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-3);
  margin-bottom: var(--space-3);
}

.chart-panel__title {
  font-size: 14px;
  font-weight: 600;
  color: var(--color-text);
}
</style>
