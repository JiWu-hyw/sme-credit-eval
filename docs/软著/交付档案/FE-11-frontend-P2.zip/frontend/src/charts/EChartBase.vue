<script setup lang="ts">
/**
 * ECharts 基座（FE-03）
 *
 * ⚠️ 业务页面勿直接使用，一律走 `ChartPanel`（它强制带数据来源角标，红线一）。
 * 本组件只负责：初始化实例、响应容器尺寸、加载态遮罩、卸载销毁。
 */
import { onBeforeUnmount, onMounted, ref, shallowRef, watch } from 'vue'

import { echarts, type EChartsOption } from './echarts'

const props = withDefaults(
  defineProps<{
    option: EChartsOption
    height?: number | string
    loading?: boolean
  }>(),
  { height: 320, loading: false },
)

const el = ref<HTMLDivElement | null>(null)
// echarts 实例类型取自 core 命名空间，避免深层 import 路径漂移
const chart = shallowRef<ReturnType<typeof echarts.init> | null>(null)
let observer: ResizeObserver | null = null

function render() {
  if (!chart.value) return
  chart.value.setOption(props.option, { notMerge: true })
}

onMounted(() => {
  if (!el.value) return
  chart.value = echarts.init(el.value, undefined, { renderer: 'canvas' })
  render()
  if (typeof ResizeObserver !== 'undefined') {
    observer = new ResizeObserver(() => chart.value?.resize())
    observer.observe(el.value)
  }
})

watch(() => props.option, render, { deep: true })
watch(
  () => props.loading,
  (v) => (v ? chart.value?.showLoading('default', { text: '加载中' }) : chart.value?.hideLoading()),
)

onBeforeUnmount(() => {
  observer?.disconnect()
  chart.value?.dispose()
  chart.value = null
})
</script>

<template>
  <div
    ref="el"
    class="echart-base"
    :style="{ height: typeof height === 'number' ? `${height}px` : height }"
    role="img"
  />
</template>

<style scoped>
.echart-base {
  width: 100%;
}
</style>
