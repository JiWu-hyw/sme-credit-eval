/**
 * ECharts 按需注册（FE-11 最小集合）
 *
 * 只注册 P2 用到的图表与组件；按需注册把 echarts 包从 ~1MB 压到 ~400KB，
 * 力导向图等其余模块由 P3 任务补。
 *
 * 类型说明：Option 用 `ECBasicOption` 宽松承接（各 series 的 option 类型在 echarts/core
 * 命名空间里并不导出），业务侧组装 option 时由编译期检查 series 的 `type` 字面量即可。
 */
import * as echarts from 'echarts/core'
import { BarChart, CustomChart, HeatmapChart, LineChart, ScatterChart } from 'echarts/charts'
import {
  DatasetComponent,
  GridComponent,
  LegendComponent,
  MarkLineComponent,
  TitleComponent,
  TooltipComponent,
  VisualMapComponent,
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'

echarts.use([
  BarChart,
  CustomChart,
  HeatmapChart,
  LineChart,
  ScatterChart,
  DatasetComponent,
  GridComponent,
  LegendComponent,
  MarkLineComponent,
  TitleComponent,
  TooltipComponent,
  VisualMapComponent,
  CanvasRenderer,
])

/** 图表 option：结构由各 series 自身决定，这里只约束顶层 */
export type EChartsOption = Record<string, unknown>

export { echarts }
