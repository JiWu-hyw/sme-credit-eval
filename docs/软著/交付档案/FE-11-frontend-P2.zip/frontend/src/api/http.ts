/**
 * HTTP 客户端（FE-02）
 *
 * 统一拦截器：
 *   - 响应信封原样透传（code / message / data / meta），不在这一层改字段名；
 *   - 错误归一为 ApiError，交给 utils/errors.ts 翻译成「原因 + 下一步」。
 */
import axios, { type AxiosError, type AxiosInstance } from 'axios'

export class ApiError extends Error {
  code?: string
  status?: number
  response?: { status?: number; data?: { code?: string; message?: string } }

  constructor(message: string, opts: { code?: string; status?: number } = {}) {
    super(message)
    this.name = 'ApiError'
    this.code = opts.code
    this.status = opts.status
  }
}

export const http: AxiosInstance = axios.create({
  baseURL: import.meta.env?.VITE_API_BASE ?? '/api',
  timeout: 30_000,
})

http.interceptors.response.use(
  (res) => res,
  (error: AxiosError<{ code?: string; message?: string }>) => {
    const status = error.response?.status
    const data = error.response?.data
    throw new ApiError(data?.message ?? error.message ?? '请求失败', {
      code: data?.code,
      status,
    })
  },
)
