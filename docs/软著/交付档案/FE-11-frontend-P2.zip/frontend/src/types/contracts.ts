/**
 * 契约类型镜像（FE-02 / FE-11 扩充）。
 *
 * 纪律（fe-spec §6）：字段名逐字对齐 outputs/contracts/*.json，**不做 camelCase 转换**、
 * **不简化结构**。契约文件是单一事实源，这里只是镜像；真实契约落地后如有出入，
 * 以 outputs/contracts/*.json 为准回改本文件。
 *
 * FE-11 补齐 P2「数据与特征」四区块：
 *   DataPipeline（A01）/ DataQuality（A02）/ PanelDepth（A03）/ FeatureTree（A04）
 */

import type { ContractMeta, DatasetKind, EntityKindKey, RiskBandKey } from './index'

export type { ContractMeta, DatasetKind, EntityKindKey, RiskBandKey }

/** 统一响应包 */
export interface ApiEnvelope<T = unknown> {
  code: string | number
  message: string
  data: T
  meta?: ContractMeta
}

/* ---------------------------- A01 数据接入链路 ---------------------------- */

export type PipelineNodeKind = 'source' | 'process' | 'dataset'

/** 节点状态：ready 已就绪 / partial 部分 / pending 待接入 / blocked 阻塞 / synthetic_only 仅合成 */
export type PipelineStatus = 'ready' | 'partial' | 'pending' | 'blocked' | 'synthetic_only'

export interface PipelineNode {
  id: string
  name: string
  kind: PipelineNodeKind
  status?: PipelineStatus
  description?: string
}

export interface PipelineEdge {
  from: string
  to: string
  label?: string
  status?: PipelineStatus
}

export interface PipelineStep {
  order: number
  name: string
  impl: string
  detail: string
  status: PipelineStatus
}

export interface DataPipeline {
  nodes: PipelineNode[]
  edges: PipelineEdge[]
  steps?: PipelineStep[]
}

/* ----------------------------- A02 数据质量 ------------------------------ */

export interface QualityField {
  field: string
  semantic_known: boolean
  label_ref?: string
  missing_rate: number
  winsorized: boolean
  dtype?: string
  n_non_null?: number
  skew_after?: number
  outlier_rate?: number
}

export interface MissingCell {
  field: string
  semantic_known: boolean
  year: string
  missing_rate: number
}

/** 缩尾前后箱线图数据（q05/q25/q50/q75/q95） */
export interface WinsorBox {
  field: string
  semantic_known: boolean
  stage: 'before' | 'after'
  q05: number
  q25?: number
  q50: number
  q75?: number
  q95: number
  n_trimmed?: number
}

export interface QualitySummary {
  n_fields: number
  n_fields_missing_gt_30pct: number
  mean_missing_rate: number
  semantic_known_ratio: number
  rows_total: number
  enterprises: number
  winsor_bounds?: { lower_pct: number; upper_pct: number; fit_on: string }
  split_rule?: string
}

export interface DataQuality {
  summary?: QualitySummary
  fields: QualityField[]
  missing_matrix: MissingCell[]
  winsor: WinsorBox[]
}

/* ---------------------------- A03 面板观测纵深 ---------------------------- */

export interface DepthBin {
  range: string
  lo?: number
  hi?: number
  enterprises: number
  observations: number
}

export interface DepthCoverage {
  months_total: number
  enterprises_with_panel: number
  median_months: number
  mean_months?: number
  p90_months?: number
  observations_total?: number
  long_sequence_feasible?: boolean
  temporal_unit?: string
}

export interface PanelDepth {
  bins: DepthBin[]
  coverage: DepthCoverage
}

/* ----------------------------- A04 特征体系树 ----------------------------- */

export interface FeatureLeafDetail {
  dtype: string
  missing_rate: number
  winsorized: boolean
  standardized: boolean
  fit_scope: string
  in_graph: boolean
  shap_rank: number | null
  semantic_status: string
  semantic_note: string
}

export interface FeatureLeaf {
  kind: 'leaf'
  field: string
  semantic_known: boolean
  label_ref: string
  type: string
  missing_rate: number
  used_in_model: boolean
  note?: string
  detail?: FeatureLeafDetail
}

export interface FeatureBranch {
  kind: 'branch'
  name: string
  code?: string
  level?: number
  hint?: string
  /** true / false / 'partial'（部分就绪） */
  data_ready?: boolean | 'partial'
  children: FeatureNode[]
}

export type FeatureNode = FeatureBranch | FeatureLeaf

export interface FeatureFlatRow {
  field: string
  semantic_known: boolean
  path: string
  type: string
  missing_rate: number
  used_in_model: boolean
}

export interface FeatureTreeSummary {
  level1: number
  level2: number
  leaves: number
  used_in_model: number
  semantic_known_leaves: number
  data_ready_branches: number
  blocked_by: string[]
}

export interface FeatureTree {
  roots: FeatureNode[]
  flat?: FeatureFlatRow[]
  summary?: FeatureTreeSummary
}

/* ------------------------- P4 模型与对比（实测基准） ------------------------- */

/** 一套指标（holdout 用全六项；CV 只产出 auc/ks/accuracy/recall/f1） */
export interface MetricSet {
  auc: number
  ks: number
  accuracy: number
  precision?: number
  recall: number
  f1: number
}

export interface BenchmarkModelCv {
  model_id: string
  model_label: string
  metrics_mean: MetricSet
  metrics_std: MetricSet
}

export interface BenchmarkLevel {
  level_id: string
  level_label: string
  n_samples: number
  n_groups: number
  n_splits: number
  k_features: number
  is_permutation_control: boolean
  models: BenchmarkModelCv[]
}

export interface BenchmarkModelHoldout {
  model_id: string
  model_label: string
  metrics: MetricSet
  threshold: number
  best_f1: number
  best_f1_threshold: number
}

export interface Benchmark {
  levels: BenchmarkLevel[]
  holdout: {
    n_train: number
    n_test: number
    n_pos: number
    selected_features: string[]
    models: BenchmarkModelHoldout[]
  }
  noise_floor: {
    value: number
    label: string
    source: string
    raw?: Record<string, number>
    note?: string
  }
  notes: string[]
}

/* --------------------------- P5 全局 SHAP 解释 --------------------------- */

export interface ShapFeatureRow {
  rank: number
  feature: string
  semantic_known: boolean
  mean_abs_shap: number
  share: number
  /** +1 风险因子（值越大越推高违约概率）/ −1 保护因子 */
  direction: number
  hint: string
}

export interface ShapModelBlock {
  model_id: string
  model_label: string
  top: ShapFeatureRow[]
  top20_share: number
  unknown_field_share: number
  n_features: number
}

export interface ShapGlobal {
  explain_set: string
  n_features_used: number
  models: ShapModelBlock[]
  conclusion: string
}

/* ----------------------------- 其余端点（占位） ----------------------------- */

/* eslint-disable @typescript-eslint/no-explicit-any */
export type OverviewSummary = Record<string, any>
export type GraphStructure = Record<string, any>
export type GraphSlices = Record<string, any>
export type GraphCentrality = Record<string, any>
export type TrainCurve = Record<string, any>
export type RocPrKs = Record<string, any>
export type PermutationControl = Record<string, any>
export type StageFactorWeight = Record<string, any>
export type LocalExplain = Record<string, any>
export type Survival = Record<string, any>
export type Financing = Record<string, any>
export type EnterpriseDetail = Record<string, any>
export type OutputsManifest = Record<string, any>

export interface BatchUploadResult {
  job_id: string
  accepted_rows: number
}

export interface BatchResultRow {
  row_no: number
  userid?: string
  enterprise_name: string
  certificate_no: string
  status: 'ok' | 'error' | 'pending'
  error_code?: string
  message?: string
  credit_score?: number
  risk_band?: RiskBandKey
  top_factors?: string[]
}

export interface BatchStatus {
  job_id: string
  state: 'queued' | 'running' | 'done' | 'failed'
  progress: { total: number; done: number; failed: number }
  error_summary?: Record<string, number>
  page?: { page: number; page_size: number; total: number }
  results: BatchResultRow[]
}
