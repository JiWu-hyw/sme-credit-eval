/**
 * 接口层（FE-02 收口点）
 *
 * 页面只 import 本文件，**永远不直接 import axios / mock**——切模式零改页面代码。
 * FE-11 只用到 P2 的四个端点，其余端点保持同样的信封结构，由后续任务补齐实现。
 *
 * 模式（VITE_USE_MOCK）：
 *   mock  → 只用契约同构 mock
 *   real  → 只用真实接口，失败如实抛出
 *   auto  → 默认。真实接口优先；命中阻塞码 / 网络错误自动降级 mock
 */
import type { ApiEnvelope } from '@/types/contracts'
import type { ContractMeta } from '@/types'

import { http } from './http'
import { getMock, getMockMode } from './mock'
import type { MockMode } from './mock'

export { configureMock, getMockMode } from './mock'
export type { MockMode }

/** 端点 key → 契约路径（与 fe-spec §6 表逐行对应，供冒烟与文档核对） */
export const ENDPOINT_PATHS = {
  'overview/summary': 'GET /api/overview/summary',
  'data/pipeline': 'GET /api/data/pipeline',
  'data/quality': 'GET /api/data/quality',
  'data/panel-depth': 'GET /api/data/panel-depth',
  'features/tree': 'GET /api/features/tree',
  'graph/structure': 'GET /api/graph/structure',
  'graph/slices': 'GET /api/graph/slices',
  'graph/centrality': 'GET /api/graph/centrality',
  'model/train-curve': 'GET /api/model/train-curve',
  'model/benchmark': 'GET /api/model/benchmark',
  'model/roc-pr-ks': 'GET /api/model/roc-pr-ks',
  'model/noise-floor': 'GET /api/model/noise-floor',
  'explain/global': 'GET /api/explain/global',
  'explain/stage-factor': 'GET /api/explain/stage-factor',
  'explain/local': 'GET /api/explain/local/{userid}',
  'enterprise/detail': 'GET /api/enterprise/{userid}',
  'batch/upload': 'POST /api/batch/upload',
  'batch/status': 'GET /api/batch/{job_id}',
  'batch/export': 'GET /api/batch/{job_id}/export',
  'forecast/survival': 'GET /api/forecast/survival',
  'forecast/financing': 'GET /api/forecast/financing',
  'outputs/manifest': 'GET /api/outputs/manifest（前端回执新增，不计入 21）',
} as const

export type EndpointKey = keyof typeof ENDPOINT_PATHS

/** 阻塞码：契约 / 标签 / 批次运行中（运行中是合法态，不降级） */
const PENDING_CODES = new Set(['CONTRACT_PENDING', 'LABEL_PENDING'])

/**
 * 形状校验：这个响应**到底是不是**约定的信封？
 *
 * 踩坑（2026-10-22 线上白屏）：
 *   静态托管 / 网关对 `/api/*` 未命中接口时会回落 `index.html`，
 *   于是 axios 拿到 200 + 一段 HTML，`res.data` 是字符串。
 *   原来的实现只看 `code`，字符串上没有 `code`，既不命中阻塞码也不报错，
 *   就把 HTML 当信封交给了页面；页面读 `pipeline.nodes` 得到 undefined，
 *   在 `.filter()` 上抛 TypeError，整页被错误态替换。
 *
 * 所以：`code` 必须是数字或字符串、`data` 必须存在且不是字符串（对象 / 数组才算），
 * 否则视为「响应不是约定信封」，在 auto 模式下按可用性降级 mock。
 */
function isEnvelope(body: unknown): body is ApiEnvelope<unknown> {
  if (!body || typeof body !== 'object' || Array.isArray(body)) return false
  const b = body as Record<string, unknown>
  const codeOk = typeof b.code === 'number' || typeof b.code === 'string'
  const dataOk = b.data !== undefined && b.data !== null && typeof b.data !== 'string'
  return codeOk && dataOk
}

/** 请求头：明确要 JSON，别让网关把我们当页面请求处理 */
const JSON_ACCEPT = 'application/json'

async function call<T>(
  key: EndpointKey,
  url: string,
  params?: Record<string, unknown>,
): Promise<ApiEnvelope<T>> {
  const mode = getMockMode()
  if (mode === 'mock') return getMock(key) as ApiEnvelope<T>

  try {
    const res = await http.get<ApiEnvelope<T>>(url, { params, headers: { Accept: JSON_ACCEPT } })
    const body = res.data
    if (mode === 'auto') {
      if (!isEnvelope(body)) {
        // 非约定信封（典型是登录页 / index.html / 网关错误页）→ 按不可用处理
        return getMock(key) as ApiEnvelope<T>
      }
      if (PENDING_CODES.has(String(body.code))) return getMock(key) as ApiEnvelope<T>
    }
    return body
  } catch (error) {
    if (mode === 'auto') return getMock(key) as ApiEnvelope<T>
    throw error
  }
}

/* --------------------------------- P1 概览 --------------------------------- */

/** P1 GET /api/overview/summary —— 全站状态聚合（六份契约的汇总视图） */
export const fetchOverviewSummary = () => call('overview/summary', '/overview/summary')

/* ----------------------------- P2 数据与特征 ----------------------------- */

/** A01 GET /api/data/pipeline —— 数据接入链路 */
export const fetchDataPipeline = () => call('data/pipeline', '/data/pipeline')

/** A02 GET /api/data/quality —— 数据质量诊断 */
export const fetchDataQuality = () => call('data/quality', '/data/quality')

/** A03 GET /api/data/panel-depth —— 面板观测纵深 */
export const fetchPanelDepth = () => call('data/panel-depth', '/data/panel-depth')

/** A04 GET /api/features/tree —— 特征体系三级树 */
export const fetchFeatureTree = () => call('features/tree', '/features/tree')

/* ------------------------- P4 模型与对比 / P5 全局解释 ------------------------- */

/** P4 GET /api/model/benchmark —— 基线 + 图模型 + 无图对照 + 消融 + 2×2 矩阵（实测锚点） */
export const fetchBenchmark = () => call<import('@/types/contracts').Benchmark>('model/benchmark', '/model/benchmark')

/**
 * P4 GET /api/model/train-curve —— 模型架构 + 训练曲线（A08 / A09）
 *
 * ⚠️ 契约 meta.dataset = synthetic_graph、source = reconstructed_from_anchors：
 * 曲线是「端点锚定 + 形状重建」，不是真实训练日志。页面必须单独成区块并标口径，
 * 不得与真实面板的 performance 图共用坐标轴（红线一 / 四）。
 */
export const fetchTrainCurve = () => call<import('@/types/contracts').TrainCurve>('model/train-curve', '/model/train-curve')

/** P4 GET /api/model/roc-pr-ks —— ROC / PR / KS 曲线族（A11） */
export const fetchRocPrKs = () => call<import('@/types/contracts').RocPrKs>('model/roc-pr-ks', '/model/roc-pr-ks')

/** P4 GET /api/model/noise-floor —— 置换对照噪声地板柱状对比（A12） */
export const fetchNoiseFloor = () =>
  call<import('@/types/contracts').NoiseFloorContract>('model/noise-floor', '/model/noise-floor')

/** P5 GET /api/explain/global —— 全局 SHAP 特征贡献（实测） */
export const fetchShapGlobal = () =>
  call<import('@/types/contracts').ShapGlobal>('explain/global', '/explain/global')

/* ------------------------------ P3 时空图谱 ------------------------------ */

/** E1 GET /api/graph/structure —— 六类实体异质图（合成图） */
export const fetchGraphStructure = () =>
  call<import('@/types/contracts').GraphStructure>('graph/structure', '/graph/structure')

/** E3 GET /api/graph/slices —— 季度时间切片（增量 + 累计 + 可见节点集） */
export const fetchGraphSlices = () =>
  call<import('@/types/contracts').GraphSlices>('graph/slices', '/graph/slices')

/** E2 GET /api/graph/centrality —— 度分布 + 四类中心性比较 */
export const fetchGraphCentrality = () =>
  call<import('@/types/contracts').GraphCentrality>('graph/centrality', '/graph/centrality')

/** 其余端点（P1/P3–P7）保持同一通道，由后续任务实现业务封装 */
export const fetchAny = <T>(key: Exclude<EndpointKey, `data/${string}` | 'features/tree'>) =>
  call<T>(key, `/${key.split('/').filter((s) => !s.startsWith('{')).join('/')}`)

export type { ContractMeta }
